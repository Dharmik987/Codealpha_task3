import requests
import folium
import webbrowser

def get_ip():
    try:
        ip = requests.get("https://api.ipify.org").text
        print(f"[INFO] Your IP Address: {ip}")
        return ip
    except Exception as e:
        print(f"[ERROR] Failed to get IP address: {e}")
        return None

def get_geolocation(ip):
    try:
        url = f"https://ipinfo.io/{ip}/json"
        response = requests.get(url)
        data = response.json()
        location = data.get('loc', '')
        city = data.get('city', 'Unknown')
        region = data.get('region', 'Unknown')
        country = data.get('country', 'Unknown')
        print(f"[INFO] Location: {city}, {region}, {country}")
        return location.split(','), city, region, country
    except Exception as e:
        print(f"[ERROR] Failed to get geolocation: {e}")
        return None, None, None, None

def generate_map(lat, lon, city):
    try:
        map = folium.Map(location=[lat, lon], zoom_start=12)
        folium.Marker([lat, lon], popup=f"Location: {city}").add_to(map)
        map_file = "geolocation_map.html"
        map.save(map_file)
        print(f"[INFO] Map saved to {map_file}")
        webbrowser.open(map_file)
    except Exception as e:
        print(f"[ERROR] Failed to generate map: {e}")

def main():
    ip = get_ip()
    if not ip:
        return
    location, city, region, country = get_geolocation(ip)
    if location:
        lat, lon = float(location[0]), float(location[1])
        generate_map(lat, lon, city)
    else:
        print("[ERROR] Unable to fetch location data.")

if __name__ == "__main__":
    main()
